const decompressZip = require('decompress-zip')

const _unzip = (zipPath, outputPath) => {
  return new Promise(async (resolve, reject) => {
    const unzipper = new decompressZip(zipPath)

    unzipper.on('error', (err)  => {
      console.log(err)
      reject(err)
    })

    unzipper.on('extract', () => {
      resolve()
    })

    unzipper.extract({
      path: outputPath,
      restrict: false
    })
  })
}

const unzip = (zipPath, outputPath) => {
  return new Promise(async (resolve, reject) => {
    let errorCount = 0

    for (let i=0; i<3; i++) {
      _unzip(zipPath, outputPath)
        .then(res => {
          resolve()
        })
        .catch(err => {
          errorCount++
          console.log(errorCount)
          if (errorCount >= 3) {
            reject('Retry limit exceeded')
          }
        })
    }
  })
}

module.exports = unzip