const fsUtils = require('./fsUtils')
const regUtils = require('./regUtils')
const vdfplus = require('vdfplus')
const { basename } = require('path')

const isSteamInstalled = () => {
  return new Promise(async (resolve, reject) => {
    regUtils
      .getRegKey('HKCU', '\\Software\\Valve\\Steam')
      .then(res => {
        resolve(!!(res && res.length > 0))
      })
      .catch(reject)
  })
}

const fetchSteamInstallDir = () => {
  return regUtils.getKey('HKCU', '\\Software\\Valve\\Steam', 'SteamPath')
}

const fetchSteamLibraryDir = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const steamInstallDir = await fetchSteamInstallDir()
      const manifestsFile = await fsUtils.loadFileToString(`${steamInstallDir}/steamapps/libraryfolders.vdf`)
      const parsedVdf = vdfplus.parse(manifestsFile)
      const steamLibraryDir = parsedVdf.LibraryFolders

      resolve(steamLibraryDir[1])
    } catch (err) {
      reject(err)
    }
  })
}

const fetchModMetadata = (path) => {
  return new Promise(async (resolve, reject) => {
    try {
      const modFiles = await fsUtils.traversePath(path)
      const isVdf = modFiles.filter(v => v.includes('.vdf')).length > 0
      const isJson = modFiles.filter(v => v.toLowerCase().includes('.json')).length > 0

      let metadata = {}
      if (isVdf) {
        const vdfPath = `${path}/${modFiles.filter(v => v.includes('.vdf'))[0]}`
        const loadedVdf = await fsUtils.loadFileToString(vdfPath)
        let vdf = vdfplus.parse(loadedVdf)
        if (vdf.workshopitem) {
          vdf = vdf.workshopitem
        }
        metadata.title = vdf.title
        metadata.description = vdf.description
        if (vdf.previewfile) {
          metadata.thumbnail = basename(vdf.previewfile)
        }
        metadata.id = vdf.publishedfileid
      } else if (isJson) {
        const jsonPath = `${path}/${modFiles.filter(v => v.toLowerCase().includes('.json'))[0]}`
        const loadedJson = await fsUtils.loadFileToString(jsonPath)
        const json = JSON.parse(loadedJson)

        metadata.title = json.Title
        metadata.description = json.Description
        if (json.Preview) {
          metadata.thumbnail = basename(json.Preview)
        }
        metadata.id = json.ItemID
      } else {
        resolve(false)
      }
      resolve(metadata)
    } catch (err) {
      reject(err)
    }
  })
}

const rocketAppId = '252950'

exports.isSteamInstalled = isSteamInstalled
exports.fetchSteamInstallDir = fetchSteamInstallDir
exports.fetchSteamLibraryDir = fetchSteamLibraryDir
exports.rocketAppId = rocketAppId
exports.fetchModMetadata = fetchModMetadata

