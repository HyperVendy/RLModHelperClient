let progressContainer = document.getElementById('progress-container')

const createProgressDiv = (id, message) => {
  progressContainer.innerHTML = progressContainer.innerHTML + `<div id="${id}" class="container-fluid"><div class="spinner-border text-success" role="status"><span class="sr-only"></span></div><span> ${message} </span></div>`
}

const update = (id, message) => {
  let progressDiv = document.getElementById(id)

  progressDiv.innerHTML = `<div class="spinner-border text-success" role="status"><span class="sr-only"></span></div><span> ${message} </span>`
}

const success = (id, message) => {
  let progressDiv = document.getElementById(id)

  progressDiv.innerHTML = `<i class="fas fa-check-circle fa-2x green-text"></i> ${message}`
}

const failure = (id, message) => {
  let progressDiv = document.getElementById(id)

  progressDiv.innerHTML = `<i class="fas fa-times-circle fa-2x red-text"></i> ${message}`
}

module.exports = {
  createProgressDiv,
  update,
  success,
  failure
}
