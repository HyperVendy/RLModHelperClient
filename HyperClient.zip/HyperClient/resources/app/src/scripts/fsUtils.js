//const { access, mkdir, unlink, readFile } = require('fs')
const fs = require('fs')
const { access, mkdir, readdir, readFile, unlink } = fs.promises

const makeDir = dir => {
  return mkdir(dir)
}

const deleteDir = dir => {
  return unlink(dir)
}

const fileOrFolderExists = dir => {
  return new Promise((resolve, reject) => {
    access(dir)
      .then(() => {
        resolve(true)
      })
      .catch(err => {
        if (err.code == 'ENOENT') {
          return resolve(false)
        } 
        reject(err)
      })
  })
}

const fileOrFolderWriteable = dir => {
  return new Promise((resolve, reject) => {
    access(dir, 3)
      .then(resolve)
      .catch(err => {
        // Todo - If error is Not Found, resolve false
        console.log(err)
        reject(err)
      })
  })
}

const loadFileToString = path => {
  return new Promise(async (resolve, reject) => {
    try {
      const exists = await fileOrFolderExists(path)
      if (!exists) {
        return reject('File not found')
      }

      readFile(path, 'utf-8')
        .then(resolve)
        .catch(err => {
          // Todo - If error is not Not Found, resolve but false
          reject(err)
        })
    } catch (err) {

    }
  })
}

const traversePath = path => {
  return new Promise(async (resolve, reject) => {
    try {
      const folders = await readdir(path)

      resolve(folders)
    } catch (err) {
      reject(err)
    }
  })
}

exports.makeDir = makeDir
exports.deleteDir = deleteDir
exports.fileOrFolderExists = fileOrFolderExists
exports.fileOrFolderWriteable = fileOrFolderWriteable
exports.loadFileToString = loadFileToString
exports.traversePath = traversePath

