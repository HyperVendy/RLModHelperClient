

const path = require('path')
const Registry = require('winreg')
const { exec } = require('child_process')
const progress = require('./scripts/progress')
const osTests = require('./scripts/osTests')
const unzip = require('./scripts/unzip')
const downloadZip = require('./scripts/download')
const fsUtils = require('./scripts/fsUtils')
const steamUtils = require('./scripts/steamUtils')
const { folder } = require('decompress-zip/lib/extractors')

const tempDir = path.join(__dirname, 'tmp')

const checkOs = () => {
  return new Promise((resolve, reject) => {
    const progressId = 'os-check'
    progress.createProgressDiv(progressId, 'Checking OS')

    if (osTests.isCurrentPlatformSupported()) {
      progress.success(progressId, 'Valid OS')
      resolve()
    } else {
      progress.failure(progressId, 'Invalid OS')
      reject()
    }
  })
}

// TODO Update this to Use Registry
const checkSteam = () => {
  return new Promise((resolve, reject) => {
    const progressId = 'steam-check'
    progress.createProgressDiv(progressId, 'Checking Steam')

    const ls = exec(`WMIC Service Where (Name Like 'Steam%%') Get Name`)

    ls.stdout.on('data', (data) => {
      if (data.indexOf('Steam') > 0) {
        progress.success(progressId, 'Steam installed')
        resolve()
      } else {
        progress.failure(progressId, 'Steam not installed')
        reject()
      }
    })

    ls.stdout.on('error', reject) 
  })
}

const checkRocketLeague = () => {
  return new Promise((resolve, reject) => {
    const progressId = 'rl-check'
    progress.createProgressDiv(progressId, 'Checking Rocket League')
    
    regKey = new Registry({
      hive: Registry.HKCU,
      key: '\\Software\\Valve\\Steam\\Apps\\252950'
    })

    regKey.values(function (err, items) {
      if (err && !err.message.includes('The system was unable to find the specified registry key or value.')) {
        reject(err)
      }
        
      if (!items || items.length < 1) {
        progress.failure(progressId, 'Failed to find Rocket League')
        return reject('Failed to find Rocket League')
      }

      progress.success(progressId, 'Rocket League Installed')
      resolve()
    })
  })
}

const installBakkesMod = (bakkesPath) => {
  return new Promise(async (resolve, reject) => {
    try {
      const downloadFile = path.join(tempDir, 'BakkesModInjector.zip')

      const fileExists = await fsUtils.fileOrFolderExists(downloadFile)
      if (fileExists) {
        await fsUtils.deleteDir(downloadFile)
      }

      const url = 'https://www.bakkesmod.com/static/BakkesModInjector.zip'
      await downloadZip(url, downloadFile)
      await unzip(downloadFile, bakkesPath)

      resolve()
    } catch (err) {
      reject(err)
    }
  })
}


const checkBakkesMod = () => {
  return new Promise(async (resolve, reject) => {
    const progressId = 'bakkes-check'
    progress.createProgressDiv(progressId, 'Checking BakkesMod')

    try {
      const bakkesPath = path.join(process.env.APPDATA, '..', 'Local/BakkesMod')
      const bakkesExe = path.join(bakkesPath, 'BakkesMod.exe')

      const folderExists = await fsUtils.fileOrFolderExists(bakkesPath)
      if (!folderExists) {
        await fsUtils.makeDir(bakkesPath)
      }

      const fileExists = await fsUtils.fileOrFolderExists(bakkesExe)
      if (!fileExists) {
        progress.update(progressId, 'Installing BakkesMod')
        await installBakkesMod(bakkesPath)
        progress.success(progressId, 'Installed BakkesMod')
      } else {
        progress.success(progressId, 'BakkesMod installed')
      }

      resolve()
    } catch (err) {
      progress.failure(progressId, 'Failed to install BakkesMod')
      reject(err)
    }
  })
}

const installRocketMod = (rocketModPath) => {
  return new Promise(async (resolve, reject) => {
    try {
      const downloadFile = path.join(tempDir, 'RocketMod.zip')

      const folderExists = await fsUtils.fileOrFolderExists(tempDir)
      if (!folderExists) {
        await fsUtils.makeDir(tempDir)
      }

      const fileExists = await fsUtils.fileOrFolderExists(downloadFile)
      console.log('file exists' + fileExists)
      if (fileExists) {
        await fsUtils.deleteDir(downloadFile)
        console.log('file deleted')
      }

      const url = 'https://d1des3ogmwbyhn.cloudfront.net/uploads/4_90f64b561dcbd0059ae6339ea5b60be53416f8083b4c2d359616c53653a2f922.zip'
      await downloadZip(url, downloadFile)
      await unzip(downloadFile, rocketModPath)
      await fsUtils.deleteDir(downloadFile)

      resolve()
    } catch (err) {
      console.log(err)
      reject(err)
    }
  })
}

const checkRocketMod = () => {
  return new Promise(async (resolve, reject) => {
    const progressId = 'rocket-mod-check'
    progress.createProgressDiv(progressId, 'Checking RocketMod')

    try {
      const steamLibraryDir = await steamUtils.fetchSteamLibraryDir()
      const modFolder = path.join(steamLibraryDir, 'steamapps/common/rocketleague/Binaries/Win64/bakkesmod')
      const rocketModDir = path.join(modFolder, 'plugins')
      const rocketModDll = path.join(rocketModDir, 'RocketPlugin.dll')

      const folderExists = await fsUtils.fileOrFolderExists(rocketModDir)
      console.log(folderExists)
      if (!folderExists) {
        await fsUtils.makeDir(rocketModDir)
      }

      const fileExists = await fsUtils.fileOrFolderExists(rocketModDll)
      console.log(fileExists)
      if (!fileExists) {
        progress.update(progressId, 'Installing RocketMod')
        await installRocketMod(modFolder)
        progress.success(progressId, 'Installed RocketMod')
      } else {
        progress.success(progressId, 'RocketMod Installed')
        
      }
      resolve()
    } catch (err) {
      progress.failure(progressId, 'Failed to install RocketMod')
      return reject(err)
    }
  })
}

const installTextures = (outputDir) => {
  return new Promise(async (resolve, reject) => {
    try {
      const tempDir = path.join(__dirname, 'tmp')
      const downloadFile = `${tempDir}\\WorkshopTextures.zip`

      const url = 'https://github.com/HyperVendy/RLModHelperClient/raw/master/Workshop-textures.zip'
      await downloadZip(url, downloadFile)
      await unzip(downloadFile, outputDir)

      resolve()
    } catch (err) {
      reject (err)
    }
  })
}

const checkTextures = () => {
  return new Promise(async (resolve, reject) => {
    const progressId = 'textures-check'
    progress.createProgressDiv(progressId, 'Checking Textures')
    try {
      const steamLibraryDir = await steamUtils.fetchSteamLibraryDir()
      const modFolder = path.join(steamLibraryDir, 'steamapps/common/rocketleague/TAGame/CookedPCConsole')
      const textureFile = path.join(modFolder, 'mods.upk')

      const fileExists = await fsUtils.fileOrFolderExists(textureFile)
      if (!fileExists) {
        progress.update(progressId, 'Installing Textures')
        await installTextures(modFolder)
        progress.success(progressId, 'Installed Textures')
        resolve()
      } else {
        progress.success(progressId, 'Textures Installed')
        resolve()
      }
    } catch (err) {
      progress.failure(progressId, 'Failed to install Textures')
      reject(err)
    }
  })
}

const checkFolder = () => {
  return new Promise(async (resolve, reject) => {
    const progressId = 'textures-check'
    progress.createProgressDiv(progressId, 'Checking Textures')
    try {
      const steamLibraryDir = await steamUtils.fetchSteamLibraryDir()
      const modFolder = path.join(steamLibraryDir, 'steamapps/common/rocketleague/TAGame/CookedPCConsole/mods')

      const folderExists = await fsUtils.fileOrFolderExists(modFolder)
      if (!folderExists) {
        progress.update(progressId, 'Creating Folders')
        await fsUtils.makeDir(modFolder)
        progress.success(progressId, 'Created Folder')
      }
        
      progress.success(progressId, 'Folders created')
      resolve()
    } catch (err) {
      progress.failure(progressId, 'Failed to create Folders')
      reject(err)
    }
  })
}

const cleanup = () => {
  return new Promise(async (resolve, reject) => {
    try {
      //await fsUtils.deleteDir(tempDir)
      resolve()
    } catch (err) {
      reject(err)
    }
  })
}

runChecks = async() => {
  try {
    await checkOs()
    await checkSteam()
    await checkRocketLeague()
    await checkBakkesMod()
    await checkRocketMod()
    await checkTextures()
    await checkFolder()
    await cleanup()
    
    const checkContainer = document.getElementById('check-container')

    checkContainer.hidden = true
  } catch (err) {
    console.log(err)
  }
}

runChecks()
