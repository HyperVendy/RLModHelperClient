const os = require('os')

const _platforms = {
  WINDOWS: 'WINDOWS',
  MAC: 'MAC',
  LINUX: 'LINUX',
  SUN: 'SUN',
  OPENBSD: 'OPENBSD',
  ANDROID: 'ANDROID',
  AIX: 'AIX'
}

const _platformNames = {
  win32: { platform: _platforms.WINDOWS, supported: true },
  darwin: { platform: _platforms.MAC, supported: false },
  linux: { platform: _platforms.LINUX, supported: false },
  sunos: { platform: _platforms.SUN, supported: false },
  openbsd: { platform: _platforms.OPENBSD, supported: false },
  android: { platform: _platforms.ANDROID, supported: false },
  aix: { platform: _platforms.AIX, supported: false },
}

const currentPlatform = () => {
  return _platformNames[os.platform()].platform
}

const isCurrentPlatformSupported = () => {
  return _platformNames[os.platform()].supported
}

module.exports = {
  currentPlatform,
  isCurrentPlatformSupported
}