const registry = require('winreg')

const keyExists = (hive, key) => {
  return new Promise((resolve, reject) => {
    try {
      regKey = new registry({
        hive: registry[hive],
        key: key
      })

      regKey.values((err, values) => {
        if (err) {
          if (err.message.includes('The system was unable to find the specified registry key or value.')) {
            resolve(false)
          } else {
            reject(err)
          }
        } else { resolve(true) }
      })
    } catch (err) {
      reject(err)
    }
  })
}

const getKey = (hive, key, value) => {
  return new Promise((resolve, reject) => {
    try {
      regKey = new registry({
        hive: registry[hive],
        key: key
      })

      regKey.values((err, values) => {
        if (err) {
          if (err.message.includes('The system was unable to find the specified registry key or value.')) {
            // Resolve, but bad boy
            return resolve(false)
          } else {
            return reject(err)
          }
        }

        const val = values.filter(val => val.name == 'SteamPath')
        
        resolve(val[0].value)
      })
    } catch (err) {
      reject(err)
    }
  })
}

exports.keyExists = keyExists
exports.getKey = getKey
