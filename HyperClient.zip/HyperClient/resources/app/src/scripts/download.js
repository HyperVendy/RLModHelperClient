const fs = require('fs')

const _saveFile = async (reader, writer) => {
  while(true) {
    const { done, value } = await reader.read()
    if (done) {
      break
    }

    if (value == null) {
      throw Error('Empty chunk')
    } else {
      writer.write(Buffer.from(value))
    }
  }
}

const downloadZip = (url, output) => {
  return new Promise(async (resolve, reject) => {
    console.log('downloading')
    const response = await fetch(new Request(url))

    if (!response.ok) {
      return reject(response)
    }

    const body = response.body
    if (!body) {
      return reject('No response body')
    }

    const reader = body.getReader()
    const writer = fs.createWriteStream(output)
    await _saveFile(reader, writer)
    writer.end()
    resolve()
  })
}

module.exports = downloadZip