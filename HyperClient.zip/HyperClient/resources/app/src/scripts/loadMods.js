//const steamUtils = require('./scripts/steamUtils')
const fs = require('fs')
const { copyFile } = fs.promises
const { traversePath } = require('./scripts/fsUtils')

const installMod = async (id, element) => {
  try {
    const steamLibrary = await steamUtils.fetchSteamLibraryDir()
    const workshopPath = path.join(steamLibrary, 'steamapps/workshop/content', steamUtils.rocketAppId)
    const rocketLeagueMapPath = path.join(steamLibrary, 'steamapps/common/rocketleague/TAGame/CookedPCConsole/mods')
    const mapToReplace = path.join(rocketLeagueMapPath, 'Labs_Underpass_P.upk')
    const modPath = path.join(workshopPath, id)

    const modFiles = await traversePath(modPath)
    const modFile = modFiles.filter(v => v.includes('.udk'))[0]
    const source = path.join(workshopPath, id, modFile)
    await copyFile(source, mapToReplace)
    alert('Mod Map Loaded')
  } catch (err) {
    console.log(err)
  }
}

const fetchMods = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const steamLibrary = await steamUtils.fetchSteamLibraryDir()
      const workshopPath = path.join(steamLibrary, 'steamapps/workshop/content', steamUtils.rocketAppId)
      
      const modPaths = await traversePath(workshopPath)

      let mods = []
      for (let i=0; i<modPaths.length; i++) {
        const modPath = path.join(workshopPath, modPaths[i])
        const metadata = await steamUtils.fetchModMetadata(modPath)
        if (metadata && metadata.title) {
          mods.push(metadata)
        }
      }

      resolve(mods)
    } catch (err) {
      console.log(err)
      reject(err)
    }
  })
}

const displayMods = (mods) => {
  return new Promise(async (resolve, reject) => {
    try {
      let modContainer = document.getElementById('mod-manager')
      const steamLibrary = await steamUtils.fetchSteamLibraryDir()
      const workshopPath = path.join(steamLibrary, 'steamapps/workshop/content', steamUtils.rocketAppId)
      
      for (let i=0; i<mods.length; i++) {
        const thumbnail = mods[i].thumbnail && mods[i].id
          ? path.join(workshopPath, `${mods[i].id}`, mods[i].thumbnail)
          : 'https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(67).jpg'

        const modHtml = `<div class="card col-md-4"><div class="view overlay"><img class="card-img-top" src="${thumbnail}" alt="Card image cap"> <a href="#!"><div class="mask rgba-white-slight"></div></a></div><div class="card-body"><h4 class="card-title">${mods[i].title || 'No Title'}</h4><p class="card-text">${mods[i].description || 'No Description'}</p><a href="#" class="btn btn-primary" onclick="installModClick(this)" data-id="${mods[i].id}">Load</a></div></div>`

        modContainer.innerHTML = modContainer.innerHTML + modHtml
      }

      resolve()
    } catch (err) {
      console.log(err)
      reject(err)
    }
  })
}

const installModClick = (e) => {
  const id = e.dataset.id
  installMod(id, e)
}

const loadMods = async () => {
  try {
    const mods = await fetchMods()
    await displayMods(mods)
  } catch (err) {
    console.log(err)
  }
}

loadMods()
